<?php

//make sure browser see this page as utf-8 encoded HTML
header('Content-Type:text/html;charset=utf-8');
$limit = 10;
$query = isset($_REQUEST['q'])? $_REQUEST['q']:false;
$results = false;
$flag = 0;
if($query)
{
    require_once('solr-php-client-master/Apache/Solr/Service.php');

    $solr = new Apache_Solr_Service('localhost', 8983,'/solr/irhw4');

    $params = [];
    if($_GET['radio'] == 'pagerank')
	{
		$params['sort'] = "pageRankFile desc";
		$flag = 1;
	}
    else if($_GET['radio'] == 'lucene')
	{
		$params['sort'] = "";
		$flag = 0;
	}
	$results = $solr->search($query, 0, $limit, $params);
}
?>

<html>
<head>
<title>PHP Solr Client Example</title>
</head>
<body>
<form accept-charset="utf-8" method="get">
<label for="q">Type to Search:</label>
<input id="q" name="q" type="text" value="<?php echo htmlspecialchars($query, ENT_QUOTES,'utf-8'); ?>"/>
<input type="submit"/>
<input type="radio" name ="radio" value ="lucene" <?php if($flag==0) echo "checked"?>>Lucene</input>
<input type="radio" name ="radio" value ="pagerank" <?php if($flag==1) echo "checked"?>>PageRank</input>
</form>
<?php 

//display results
if($results)
{
    $total = (int)$results->response->numFound;
    $start = min(1,$total);
    $end = min($limit, $total);
    ?>
    <h2><div>Search Results<?php echo $start; ?> - <?php echo $end; ?> of <?php echo $total; ?>:</div></h2>
    <ol>
    <?php
    $url_array = [];
    //iterate through result documents
    foreach($results->response->docs as $doc)
    {
        ?> 
	<li>   
        <?php
	
        //iterate through document fields, values
        foreach($doc as $field => $value)
        {
            ?>
            <?php

		if($field == "title")
		{
		$title = $value;
		}
		else if($field =="og_url")
		{
		$url = $value;
		}
		else if($field =="id")
		{
		$id = $value;
		}
		else if($field =="description")
		{
		$description = $value;
		}
        }
	if(isset($title) && is_array($title) && sizeof($title)>1)
	{
		$title = implode("\n", $title);
        	echo "Title-->	<a target='_blank' href ='".$url."'>".$title."</a><br>";
	}
	else if(isset($title))
	{
		echo "Title-->	<a target='_blank' href ='".$url."'>".$title."</a><br>";
	}
	if(isset($url) && is_array($url) && sizeof($url)>1)
	{
		$url = implode("\n", $url);
		echo "URL Link-->	<a target='_blank' href ='".$url."'>".$url."</a><br>";
	}
	else if(isset($url))
	{
		echo "URL Link-->	<a target='_blank' href ='".$url."'>".$url."</a><br>";
	}
	if(isset($id) && is_array($id) && sizeof($id)>1)
	{
		$id = implode("\n", $id);
		echo "ID-->	.$id.<br>";
	}
	else if(isset($id))
	{
		echo "ID-->	.$id.<br>";
	}
	if(isset($description) && is_array($description) && sizeof($description)>1)
	{
		$description = implode("\n", $description);
		echo "Description-->	.$description.<br>";
	}
	else if(isset($description))
	{
		echo "Description-->	.$description.<br>";
	}
	echo "<br>";
    }
}

    ?>
    </ol>
  
</body>
</html>