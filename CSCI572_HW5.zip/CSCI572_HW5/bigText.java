import java.io.BufferedWriter;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;

import org.apache.tika.exception.TikaException;
import org.apache.tika.sax.BodyContentHandler;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.html.HtmlParser;
import org.apache.tika.parser.ParseContext;
import org.xml.sax.SAXException;



public class bigText {
	
	public static void WriteFile(ArrayList<String> listOfWords) throws IOException
	{
		BufferedWriter writer = new BufferedWriter(new FileWriter("big.txt"));
		for(int i=0;i<listOfWords.size();i++)
		{
		    writer.write(listOfWords.get(i)+"\n");
		}
		//writer.close();
	}
	public static void parseFiles(String directoryPath)throws FileNotFoundException, TikaException, SAXException, IOException
	{
        File dir = new File(directoryPath);
        File[] files = dir.listFiles();
        //temp value for checking is .txt runs for some values
        //int i =0;
        ArrayList<String> fullList = new ArrayList();
        for(File x: files)
        {
        	fullList.addAll(parseFile(x));
        }
        WriteFile(fullList);
	}
	
	public static ArrayList<String> parseFile(File myFile) throws TikaException, FileNotFoundException, IOException, SAXException
	{
	      BodyContentHandler handler = new BodyContentHandler(-1);
	      FileInputStream inputstream = new FileInputStream(myFile);
	      ParseContext pcontext = new ParseContext();
	      Metadata metadata = new Metadata();
	      HtmlParser htmlparser = new HtmlParser();
	      htmlparser.parse(inputstream, handler, metadata,pcontext);
	      String ans = handler.toString();
	      ArrayList bigList = new ArrayList(Arrays.asList(ans.split("\\W+")));
	      return bigList;
	}
	
	public static void main(String args[]) throws FileNotFoundException, SAXException, IOException, TikaException 
		{
			//get the path
			String directoryPath= "D:\\MSCS\\Sem 2\\IR\\IR Assignment 4\\crawl_data";
			parseFiles(directoryPath);
		}
}
