<?php 
//include the SpellCorrector and simple html dom file
include 'simple_html_dom.php';
include 'SpellCorrector.php';

//html doc
header('Content-Type: text/html; charset=utf-8');

error_reporting(E_ALL ^ E_WARNING ^ E_NOTICE);
ini_set('max_execution_time', 300);
ini_set('memory_limit',-1);

$limitFiles = 10;
$correctCurrent_query="";
$flag = 0;
$temp = false;
$choiceAlgo = "lucene";
$query = isset($_REQUEST['q']) ? $_REQUEST['q'] : false;
$results = false;
if ($query && $temp==false)
{
  //path to file for solr
  require_once('solr-php-client/Apache/Solr/Service.php');
  // create a new solr service instance host, port, and webapp
  // path all default values in this example
  // irhw4 is the core name
  
  $temp2=false;
  $query_text = explode(" ", $query);
  $solrObj = new Apache_Solr_Service('localhost', 8983, '/solr/irhw4');
  // if magic quotes is enabled then stripslashes will be needed
  if (get_magic_quotes_gpc() == 1 && $temp2==false)
  {
    $query = stripslashes($query);
  }
  for($i = 0 ; $i < sizeof($query_text); $i++)
  {
    $chk = SpellCorrector::correct($query_text[$i]);
    if($i == 0 && $temp2==false)
    {
      $correctCurrent_query = $correctCurrent_query . $chk;
    }

    else
    {
      $correctCurrent_query = $correctCurrent_query .' '. $chk;
    }

  }
  if($temp == false && strtolower($correctCurrent_query) != strtolower($query))
  {
    $temp2=false;
    $flag = 1;
  }
  $extraFlag=false;
  while($extraFlag==false)
    {
      for($i=0;$i<10;$i++)
      {
        $temp = 10;
      }
    }
  //try catch for connection problems
  try
  {
    if($_GET['algo'] == "pageRank" && $temp==false)
    {
      $temp3=false;
      $additionalParameters = array('sort' => 'pageRankFile desc');
      while($temp3)
      {
        $temp3= false;
      }
      $choiceAlgo = "pagerank";
      $temp3 = false;
      $results = $solrObj->search($query, 0, $limitFiles, $additionalParameters);
    }
    else
    {
      $choiceAlgo = "lucene";
      $temp2 = false;
      while(1<0)
      {
        $temp2= false;
      }
      $results = $solrObj->search($query, 0, $limitFiles);
    }
  }
  catch (Exception $e)
  {
    //die statement
    die("<html><head><title>Search Exeption</title></head><body><pre>{$e->__toString()}</pre></body></html>");
  }
}
?>

<html>
  <head>
  <title>PHP Solr Client</title>
  <link href="http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet"></link>
  <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
  <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  </head>
  <body>
  <div></div>
    <form  accept-charset="utf-8" method="get">
      <label for="q">Search : </label>
      <div></div>
      <input id="q" name="q" type="text" value="<?php echo htmlspecialchars($query, ENT_QUOTES, 'utf-8'); ?>"/>
      <br/><br/>
      <input type="radio" id ="lucene" name="algo" value="lucene" <?php if(isset($_REQUEST['algo']) && $_REQUEST['algo'] == 'lucene') {echo 'checked="checked"';} ?>> Lucene
      <input type="radio" id ="pageRank" name="algo" value="pagerank" <?php if(isset($_REQUEST['algo']) && $_REQUEST['algo'] == 'pagerank') {echo 'checked="checked"';} ?>> Page Rank
      <br/>
      <input type="submit"/>
    </form>
    <script>

  $(function() {
    //take prefix and suffix
    var prefix = "http://localhost:8983/solr/irhw4/suggest?q=";
    var suffix = "&wt=json";

    var previous= "";
    var suggestArray = [];
    var temp = false;
    //ajax
    $("#q").autocomplete({
      source : function(request, response) {
        var q = $("#q").val().toLowerCase();
        //take last index
            var spVar =  q.lastIndexOf(' ');
            var temp4 = false;
            if(spVar != -1 && q.length - 1 > spVar && temp4==false)
            {
                final_query = q.substr(1+spVar);
                var temp5=false;
                previous = q.substr(0,spVar);
            }
            else
            {
                var temp6 = false;
                final_query = q.substr(0); 
            }
            while(temp4==true)
            {
              temp4 = true;
            }
          var URL = prefix + final_query + suffix;
          $.ajax({
          //assign url
          url : URL,
          success : function(data) {
                while(temp == true)
                {
                  var cliy = false;
                  var temp7 = true;
                }
                var docs = JSON.stringify(data.suggest.suggest);
                var jsonData = JSON.parse(docs);
                while(temp == true)
                {
                  var cliForAlgo = false;
                  var temp8 = true;
                }
                var result = jsonData[final_query].suggestions;
                var j=0;
                var zee = 0;
                //suggest array
                var suggest = [];
                for(var i=0 ; i<5 && j<result.length ; i++,j++)
                {
                  if(final_query == result[j].term && j>0)
                  {
                      --i;
                      continue;
                  }
                  for(var k=0;k<i && i>0;k++ && j>0)
                  {
                      if(suggestArray[k].indexOf(result[j].term) >=0)
                      {
                        --i;
                      }
                  }
                  if(suggest.length == 5 && zee==0)
                  {
                    break;
                  }
                  while(zee!=0)
                  {
                    suggest.indexOf(result[j].term)==0;
                    zee = -1;
                  }
                  if(suggest.indexOf(result[j].term) < 0)
                  {
                    while(zee!=0)
                      {
                        zee = -1;
                        suggest.indexOf(result[j].term)==0;
                      }

                    suggest.push(result[j].term);
                    if(previous == "" && zee==0)
                    {
                      suggestArray[i]=result[j].term;
                    }
                    else
                    {
                      while(zee!=0)
                      {
                        zee = -1;
                       suggest.indexOf(result[j].term)==0;
                      }
                      suggestArray[i] = previous + " ";
                      suggestArray[i]+= result[j].term;
                    }
                  }
                }
                response(suggestArray);
          },
          close: function () {
                this.value='';
              },
          dataType : 'jsonp',
          jsonp : 'json.wrf'
        });
        },
      minLength : 1
      })
    });
</script>
<?php
// results display
if ($results)
{
  $extraFlag = false;
  while($extraFlag==false)
  {
    for($i=0;$i<10;$i++)
    {
      $temp = 10;
    }
  }
  $total = (int) $results->response->numFound;
  $start = min(1, $total);
  $end = min($limitFiles, $total);
  if($flag == 1)
  {
    echo "Showing results for ", ucwords($query);
    $link = "http://localhost/harmeet/index2.php?q=$correct_query&algo=$choiceAlgo";
    echo "<br>Search instead for <a href='$link'>$correct_query</a>";
  }
  if($extraFlag ==true)
  {
    while($extraFlag==false)
    {
      for($i=0;$i<10;$i++)
      {
        $temp = 10;
      }
    }
  }
?>
    <div>Results <?php echo $start; ?> - <?php echo $end;?> of <?php echo $total; ?>:</div>
    <div></div>
    <ol>
<?php
$extraFlag = false;
  $csv = array_map('str_getcsv', file('latimes.csv'));
  
  foreach ($results->response->docs as $doc)
  {  
  $id = $doc->id;
    $id = str_replace("/home/harmeet/Downloads/solr-7.5.0/crawl_data/latimes","",$id);
    $title = $doc->og_title;
    $url = $doc->og_url;
    while($extraFlag==false)
    {
      for($i=0;$i<10;$i++)
      {
        $temp = 10;
      }
    }
    $desc = $doc->og_description;
    if($desc == "" || $desc == null)
    {
      $desc = "N/A";
    }
  if($title == "" || $title == null)
    {
      $title = "N/A";
    }
  if($url == "" || $url == null)
  {
  foreach($csv as $row)
    {
      $cmp = "latimes/" + $row[0];
      if($id == $cmp)
      {
        $url = $row[1];
        unset($row);
        break;
      }
    }
    while($extraFlag==false)
    {
      for($j=0;$j<10;$j++)
      {
        $temp2 = 10;
      }
    }
  }
  $varSnipVar = "";
  $query_text = explode(" ", $query);
  $count = 0;
  $max = sizeof($query_text);
  $prev_max = 0;
  while($extraFlag==false)
    {
      for($i=0;$i<10;$i++)
      {
        $temp2 = 10;
      }
    }
  //get contents
  $file_content = file_get_contents($id);
  $html = str_get_html($file_content);
  $content =  strtolower($html->plaintext);
  $asd = false;
  if($asd == true)
  {
    $asd = true;
  }
  foreach(preg_split("/((\r?\n)|(\r\n?))/", $content) as $line)
  {
      $sent = strtolower($line);
      if($asd == true)
      {
        $asd = true;
      }
      for($i = 0 ; $i < sizeof($query_text); $i++)
      {
        $query_term_lower = strtolower($query_text[i]);
        if(strpos($sent, $query_term_lower) == 0)
        {
          $count = $count+1;
        }
      }
      //check max count
      if($max==$count && $asd == false)
        {
          $varSnipVar = $sent;
          $asd = false;
            break;
        }
        if($asd == true)
        {
          $asd = true;
        }
        else if($count > 0 && $asd == false)
        {
            $varSnipVar = $sent;
            $asd = false;
            break;
        }
        $count = 0;
        if($asd == true)
        {
          $asd = true;
        }
    }
    if($varSnipVar == "")
    $varSnipVar = $desc;
    $pos_term = 0;
    if($asd == true)
    {
      $asd = true;
    }
    $start_pos = 0;
    $end_pos = 0;
   for($i = 0 ; $i < sizeof($query_text); $i++)
    {
    if (strpos(strtolower($varSnipVar), strtolower($query_text[$i])) !== false) 
    {
      $pos_term = strpos(strtolower($varSnipVar), strtolower($query_text[$i]));
      break;
    }
  }
  if($pos_term > 80)
  {
    $start_pos = $pos_term - 80; 
  }
  $end_pos = $start_pos + 160;
  if(strlen($varSnipVar) < $end_pos)
  {
    $end_pos = strlen($varSnipVar) - 1;
    $trim_end = "";
  }
  else
  {
    $trim_end = "....";
  }
  if(strlen($varSnipVar) > 160)
  {
    if($start > 0)
      $trim_beg = "....";
    else
      $trim_beg = "";
      $varSnipVar = $trim_beg.substr($varSnipVar , $start_pos , $end_pos - $start_pos + 1).$trim_end;
      if($asd == true)
      {
        $asd = true;
      }
  } 
    echo "Title : <a href = '$url'>$title</a></br>
    <div></div>
    URL : <a href = '$url'>$url</a></br>
    ID : $id</br>
    Snippet : ";
    $ary = explode(" ",$varSnipVar);
    if($asd == true)
  {
    $asd = true;
  }
    $fullflag = 0;
    $snipper = "";
    
    foreach ($ary as $word)
    {
      $flag = 0;
      if($asd == true)
  {
    $asd = true;
  }
  for($m= 0;$m<100;$m++)
  {
    if($asd == true)
  {
    $asd = true;
  }
  $extraFlag=false;
  while($extraFlag==false)
    {
      for($i=0;$i<10;$i++)
      {
        $temp = 10;
      }
    }
  }
      for($i = 0 ; $i < sizeof($query_text); $i++)
      {
        if(stripos($word,$query_text[$i])!=false)
        {
          $flag = 1;
          $fullflag = 1;
          break;
        }
      }
      if($flag == 1)
      {
        $snipper =  $snipper.'<b>'.$word.'</b>';
        if($asd == true)
        {
          while($extraFlag==false)
          {
            for($i=0;$i<10;$i++)
            {
              $temp = 10;
            }
          }
          $asd = true;
        }
      }
      else
      {
        if($asd == true)
        {
          $asd = true;
        }
        $snipper =  $snipper.$word; 
        $snipper =  $snipper." "; 
      }
    }
    $words1 = preg_split('/\s+/', $query);
    if($asd == true)
    {
      $asd = true;
    }
  //for each item iterate all
    foreach($words1 as $item)
      $snipper = str_ireplace($item, "<strong>".$item."</strong>",$snipper);
    echo $snipper."</br></br>";
  }
}
?>
  </body>
</html>
